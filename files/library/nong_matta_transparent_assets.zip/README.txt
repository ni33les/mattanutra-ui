Nong Matta transparent assets

This package contains transparent-background mascot files for the MattaNutra Visual Knowledge pages.

Folder: mattanutra_library_assets/
- Transparent WebP files using the SAME file names as the current HTML pages.
- Drop this folder into any Visual Knowledge page package and replace the existing nong_*.webp files.
- If the file paths remain /mattanutra_library_assets/nong_*.webp, the HTML does not need to be changed.

Folder: png_backup/
- PNG versions with transparency for design review or use in tools that prefer PNG.

Recommended production use: WebP assets in mattanutra_library_assets/.
